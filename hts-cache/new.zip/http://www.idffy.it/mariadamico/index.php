<!-- Cached copy, generated 2018-02-21 15:07 -->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
<head>
  <!--
  template: default_bootstrap
  version:  1.01
  date:     03/05/2016
  -->
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
 <title>www.idffy.it - maria d'amico</title>

 <!-- Custom description -->

<!-- Custom keywords -->

 <link rel="shortcut icon" href="http://www.idffy.it/site_200/templates/defualt_bootstrap/favicon.ico" />
 <link href="http://www.idffy.it/site_200/templates/default_bootstrap/css/style.css" rel="stylesheet" type="text/css" />
 <!-- Dyna CSS loader -->
<link href="http://www.idffy.it/site_200/blocks/footer_registration_banner/style/block_footer_registration_banner.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/language_choice/style/block_language_choice.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/top_header_menu_responsive/style/block_top_header_menu_responsive.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/top_header_language_choice_responsive/style/block_top_header_language_choice_responsive.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/top_header_social_net_responsive/style/block_top_header_social_net_responsive.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/top_header_left_logo_block_responsive/style/block_top_header_left_logo_block_responsive.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/top_header_center_user_showname_responsive/style/block_top_header_center_user_showname_responsive.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/top_header_right_user_image_responsive/style/block_top_header_right_user_image_responsive.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/top_responsive_menu/style/block_top_responsive_menu.css" rel="stylesheet" type="text/css" />
<link href="http://www.idffy.it/site_200/blocks/footer_menu_responsive/style/block_footer_menu_responsive.css" rel="stylesheet" type="text/css" />
<!-- END Dyna CSS loader -->

<!-- Dyna JS loader -->
<script type="text/javascript" src="http://www.idffy.it/site_200/js/cookiechoices/cookiechoices.js"></script>
<!-- END Dyna JS loader -->

<!-- Dyna JS CALL loader -->
<script language="javascript">

    var called = false ;

    function addCookieAdv() {
        cookieChoices.showCookieConsentBar( 'Il sito usa i cookies per offrirti la migliore esperienza di navigazione sul sito. Continuando a navigare accetti l utilizzo dei cookies...',
                                            'CONTINUA',
                                            'Scopri di piu',
                                            'http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=5'
                                           );
        return ;
    }

    // Verifica preseneza document.addEventListener
    if( document.addEventListener )
       {
        document.addEventListener('DOMContentLoaded', addCookieAdv, false ) ;
       }

    else if ( document.attachEvent ) {  // IE

        try {
            var isFrame = window.frameElement != null ;
        } catch(e) {}

        // IE, the document is not inside a frame
        if ( document.documentElement.doScroll && !isFrame ) {
            function tryScroll(){
                if (called) return ;
                try {
                    document.documentElement.doScroll("left") ;
                    addCookieAdv() ;
                } catch(e) {
                    setTimeout(tryScroll, 10) ;
                }
            }
            tryScroll() ;
        }

        // IE, the document is inside a frame
        document.attachEvent("onreadystatechange", function(){
            if ( document.readyState === "complete" ) {
                addCookieAdv() ;
            }
        }) ;
    }


    // Old browsers
    if (window.addEventListener)
        window.addEventListener('load', addCookieAdv, false) ;
    else if (window.attachEvent)
        window.attachEvent('onload', addCookieAdv) ;
    else {
        var fn = window.onload ; // very old browser, copy old onload
        window.onload = function() { // replace by new onload and call the old one
            fn && fn() ;
            addCookieAdv() ;
        }
    }
</script>
<!-- END JS CALL loader -->

<!-- Dyna open graph injection -->
<meta property="og:type" content="article" />
<meta property="og:url" content="http://www.idffy.it/mariadamico" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/start.jpg?464779020" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/sport.jpg?440525808" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/aloe.jpg?1586209881" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/animali3.jpg?798572155" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/oil.jpg?1211291326" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/beauty.jpg?159529379" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/circle_aloe.jpg?1274331621" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/circle_products.jpg?249487060" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/circle_news.jpg?1082837215" />
<meta property="og:image" content="http://www.idffy.it/site_200/fstore/home_dirs/390300119361/UserImage/mari.jpg?590844922" />
<meta property="og:description" content="CON FOREVER LIVING IGIENE E SALUTE PER TUTTA LA FAMIGLIA Scopri di più Forever F.I.T. Scopri il programma Integratori Guarda i prodotti Aloe Vera Gel Scopri ..." />
<!-- END Dyna open graph injection -->

 <!-- Script per Flash -->
<script type="text/javascript" src="http://www.idffy.it/site_200/js/AC_RunActiveContent.js"></script>

<!-- Prototype JS -->
<script type="text/javascript" src="http://www.idffy.it/site_200/js/prototype_1.6.1.js"></script>

<!-- Jquery -->
<script type="text/javascript" src="http://www.idffy.it/site_200/js/jquery-3.2.1/jquery-3.2.1.min.js"></script>

<!-- Bootstrap JS -->
<script type="text/javascript" src="http://www.idffy.it/site_200/js/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>

<!-- Bootstrap CSS -->
<link href="http://www.idffy.it/site_200/js/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">

<!-- Funzioni JS -->
<script type="text/javascript" src="http://www.idffy.it/site_200/js/functions.js"></script>

 <script type="text/javascript">
 jQuery.noConflict();
 jQuery( document ).ready(function(){
    if( jQuery( '#TNG_main_layout_template_table_left_cell' ).length > 0 &&
        jQuery( '#TNG_main_layout_template_table_left_cell' ).is(':empty') &&
        jQuery( '#TNG_main_layout_template_table_right_cell' ).length > 0 &&
        jQuery( '#TNG_main_layout_template_table_right_cell' ).is(':empty') ) {
        jQuery( '#TNG_main_layout_template_table_left_cell' ).remove();
        jQuery( '#TNG_main_layout_template_table_right_cell' ).remove();
        jQuery( '#TNG_main_layout_template_table_center_cell' ).removeClass('col-sm-12 col-md-9 col-md-push-3 col-lg-8 col-lg-push-2').addClass('col-md-12');
    }
    else if( jQuery( '#TNG_main_layout_template_table_right_cell' ).length > 0 &&
             jQuery( '#TNG_main_layout_template_table_right_cell' ).is(':empty') ) {
        jQuery( '#TNG_main_layout_template_table_right_cell' ).remove();
        jQuery('#TNG_main_layout_template_table_center_cell' ).removeClass('col-lg-8 col-lg-push-2').addClass('col-lg-9 col-lg-push-3');
        jQuery('#TNG_main_layout_template_table_left_cell' ).removeClass('col-lg-2 col-lg-pull-8').addClass('col-lg-3 col-lg-pull-9');
    }
    else if( jQuery( '#TNG_main_layout_template_table_left_cell' ).length > 0 &&
             jQuery( '#TNG_main_layout_template_table_left_cell' ).is(':empty') ) {
        jQuery( '#TNG_main_layout_template_table_left_cell' ).remove();
        jQuery('#TNG_main_layout_template_table_center_cell' ).removeClass('col-lg-8 col-lg-push-2').addClass('col-lg-9 col-lg-push-3');
        jQuery('#TNG_main_layout_template_table_right_cell' ).removeClass('col-lg-2').addClass('col-md-pull-9 col-lg-3 col-lg-pull-9');
    }
 });
 </script>
 <!-- Files che devono  essere caricati per google analytics -->
 </head>
<body id="TNG_main_page_container" style="background-color: #E7DCC8;">
<div class="tng_main_layout_template_wrapper" >

<div id="TNG_main_layout_template_main_page_header_container"
     class="TNG_main_layout_template_main_page_header_container">
 <div id="TNG_main_layout_template_main_header_container"
      class="TNG_main_layout_template_main_header_container">
  <div id="TNG_main_layout_template_main_header_row_first"
       class="TNG_main_layout_template_main_header_row row">
   
<div class="col-xs-6 block_top_header_menu_responsive_h_menu_external_container">
 <div class="block_top_header_menu_responsive_h_menu_internal_container row">
 <div class="navbar-header pull-left">
  <button type="button"
          class="navbar-toggle collapsed"
          data-toggle="collapse"
          data-target="#tng_menu_top_header_menu_responsive_1467055096">
   <span class="sr-only">menu di navigazione</span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
  </button>
  <span class="navbar-brand visible-xs-block"></span>
 </div>
 <div id="tng_menu_top_header_menu_responsive_1467055096" class="collapse navbar-collapse pull-left">
 <ul class="nav navbar-nav navbar-left">
        <li><a href="index.php?f4o=load&f4m=tng_community_area_riservata&f4a=build_show_area_riservata" title="Area Riservata" target="">Area Riservata</a>
        </li>
        <li><a href="index.php?f4o=load&f4m=tng_community_registration&f4a=build_password_recovery_form" title="Recupera password" target="">Recupera password</a>
        </li>
        <li><a href="index.php?f4o=load&f4m=tng_community_request_registration&f4a=show_registration_request" title="Richiedi sito personale" target="">Richiedi sito personale</a>
        </li>
 </ul>
 </div>
 </div>
</div>
<div class="tng_language_selector_block_main_container col-xs-4">
 <div class="tng_language_selector_block_icon_container pull-right">
        <span class="tng_language_selector_block_selector_list_element"
            onclick="window.location.href = 'index.php?f4o=post&f4c=user_functions&f4a=exec_set_language&language_lc_code=it';" >
         <img src="http://www.idffy.it/site_200/blocks/top_header_language_choice_responsive/images/IT.png" />
        </span>
        <span class="tng_language_selector_block_selector_list_element"
            onclick="window.location.href = 'index.php?f4o=post&f4c=user_functions&f4a=exec_set_language&language_lc_code=en';" >
         <img src="http://www.idffy.it/site_200/blocks/top_header_language_choice_responsive/images/EN.png" />
        </span>
 </div>
</div>
<div class="top_header_social_net_responsive_block_main_container col-xs-2">
 <div class="top_header_social_net_responsive_block_icon_container pull-right">
 </div>
</div>  </div>
  <div id="TNG_main_layout_template_main_header_row_second"
       class="TNG_main_layout_template_main_header_row row">
   <div class="TNG_main_layout_template_outer_area_body_header_left col-xs-6 col-md-2">
<div class="tng_main_logo_block_PUBLIC_make_block_main_container">
 <div class="tng_main_logo_block_PUBLIC_make_block_logo_container">
  <a href="index.php">
   <img class="img-responsive hidden-xs hidden-sm visible-md visible-lg" style="position: relative; z-index:200 !important;" src="http://www.idffy.it/site_200/templates/default_bootstrap/images/logo-b.png" />
   <div class="visible-xs visible-sm hidden-md hidden-lg"><img class="img-responsive pull-left img-logo-small hidden-xxs" style="width: 40px;" src="http://www.idffy.it/site_200/templates/default_bootstrap/images/logo-d.png"></div>
  </a>
 </div>
</div></div>
   <div class="TNG_main_layout_template_outer_area_body_header_right col-xs-6 col-md-2 col-md-push-8">
<div class="tng_main_logo_block_PUBLIC_make_block_main_container">
 <div class="tng_main_logo_block_PUBLIC_make_block_photo_box_container">
 <img class="image-responsive" src="http://www.idffy.it/site_200/fstore/home_dirs/390300119361/UserImage/mari.jpg" />
 </div>
</div>
</div>
   <div class="TNG_main_layout_template_outer_area_body_header_center col-xs-12 col-md-8 col-md-pull-2">
    <div class="tng_site_name_block_PUBLIC_make_block_main_container">
     <div class="tng_site_name_block_PUBLIC_make_block_site_name_container">
      <a href="index.php">
       <span class="tng_site_name_block_PUBLIC_make_block_site_name_text">maria d'amico
       </span>
      </a>
     </div>
    </div></div>
  </div>
 </div>
</div>

<!-- BODY NAVIGATION -->
<nav id="TNG_main_layout_template_main_nav_container"
     class="TNG_main_layout_template_main_nav_navbar navbar navbar-default"
     role="navigation" data-spy="affix" data-offset-top="126">
 <div class="TNG_main_layout_template_main_nav_navbar_container container-fluid">
  <div class="TNG_main_layout_template_main_nav_navbar_row row">
   
<div class="col-md-12 block_top_responsive_menu_h_menu_external_container">
 <div class="block_top_responsive_menu_h_menu_internal_container row">
 <div class="navbar-header pull-left">
  <button type="button"
          class="navbar-toggle collapsed"
          data-toggle="collapse"
          data-target="#tng_menu_top_responsive_menu_1723880745">
   <span class="sr-only">menu di navigazione</span>
   <span>MENU</span>
  </button>
  <span class="navbar-brand top_responsive_menu_brand "><img class="img-responsive" src="http://www.idffy.it/site_200/fstore/referer_group_logo/logo_fenix_team.png"/></span>
 </div>
 <div id="tng_menu_top_responsive_menu_1723880745" class="top_responsive_menu_collapsible_container collapse navbar-collapse" style="">
 <ul class="nav navbar-nav">
        <li><a href="index.php?" title="Home"  target="">Home</a>
        </li>
        <li><a href="index.php?f4o=load&f4m=tng_community_contattami&f4a=build_contact_me_form" title="Chi sono"  target="">Chi sono</a>
        </li>
        <li><a href="index.php?f4o=load&f4m=tng_community_miei_appuntamenti&f4a=build_show_miei_appuntamenti" title="Eventi"  target="">Eventi</a>
        </li>
        <li><a href="index.php?f4o=load&f4m=tng_community_blog&f4a=build_show_blog" title="Blog"  target="">Blog</a>
        </li>
        <li><a href="https://shop.foreverliving.it/registrazione-sponsorizzata-390300119361.html" title="Registrazione"  target="_blank">Registrazione</a>
        </li>
        <li><a href="index.php?f4o=load&f4m=tng_community_job_opportunity&f4a=build_job_oppportunity_main_page" title="Opportunità di lavoro"  target="">Opportunità di lavoro</a>
        </li>
        <li><a href="https://shop.foreverliving.it/shop.html?Tag_utente=390300119361" title="Catalogo prodotti"  target="_blank">Catalogo prodotti</a>
        </li>
        <li><a href="https://shop.foreverliving.it/login.html?Tag_utente=390300119361" title="Area Riservata Shop"  target="_blank">Area Riservata Shop</a>
        </li>
 </ul>
 </div>
 </div>
</div>  </div>
 </div>
</nav>

<div id="TNG_main_layout_template_main_page_control_container"></div>

<div id="TNG_main_layout_template_main_page_container">
 <div id="TNG_main_layout_template_content_container" class="container">
  <div class="row">
   <div id="TNG_main_layout_template_table_center_cell" class="col-sm-12 col-md-9 col-md-push-3 col-lg-8 col-lg-push-2"><div class="TNG_module_content_contents_text_container_home"><style>
@import url(//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i);
@import url(//fonts.googleapis.com/css?family=Kaushan+Script);
#TNG_main_layout_template_content_container{width:100%!important;padding:0!important;}


/*--------- Buttons ----------*/
.btn-secondary {
  background-color:#006600;
  border:#007700;
  cursor: pointer;
}
.font {
  font-family: 'Kaushan Script', 'Helvetica Neue', Helvetica, Arial, sans-serif;
  font-size:1.5rem
}

a:hover{
  color: red;
}

/*--------- Parallax ---------*/
.section {
  padding: 100px 0;
  position: relative;
}

.section .parallax {
  width: 100%;
  height: 100vh;
  overflow: hidden;
  display: block;
  position: relative;
}
.section .parallax > img,
.section .parallax .filter > img{
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  position: relative;
  z-index: 1;
}
.section .image {
  background-size: cover;
  background-position: center center;
  background-repeat: no-repeat;
  width: 100%;
  height: 100vh;
  z-index: 2;
  position: absolute;
  display: block;
}

/*--------- Block in parallax ---------*/
.block-popup {
  padding-bottom: 0;
}

.block-popup .container {
  position: relative;
  z-index: 100;
  display: block;
  margin-top: 30vh;
  text-align: center;
}

.block-popup .parallax {
  height: auto;
}

.block-popup .image {
  height: 100%;
}

.block-popup .container {
  margin-top: 14vh;
  margin-bottom: 50px;
}

.pop {
  background: #fff;
  box-shadow: 0 32px 44px -24px rgba(0, 0, 0, 0.23), 0 20px 25px 0px rgba(0, 0, 0, 0.12), 0 15px 10px -10px rgba(0, 0, 0, 0.2);
  border-radius: 6px;
  margin-bottom: 30px;
  -webkit-transition: all 370ms cubic-bezier(0.34, 1.61, 0.7, 1);
  -moz-transition: all 370ms cubic-bezier(0.34, 1.61, 0.7, 1);
  -o-transition: all 370ms cubic-bezier(0.34, 1.61, 0.7, 1);
  -ms-transition: all 370ms cubic-bezier(0.34, 1.61, 0.7, 1);
  transition: all 370ms cubic-bezier(0.34, 1.61, 0.7, 1);
}

.pop:not(.pop-plain):not(.pop-price):hover {
  -webkit-transform: scale(1.03);
  -moz-transform: scale(1.03);
  -o-transform: scale(1.03);
  -ms-transform: scale(1.03);
  transform: scale(1.03);
  box-shadow: 0 26px 50px -10px rgba(0, 0, 0, 0.38), 0 10px 20px 0px rgba(0, 0, 0, 0.2), 0 15px 10px -10px rgba(0, 0, 0, 0.2);
}

.pop a {
  opacity: .85;
}

.pop:hover .header {
  opacity: 1;
}

.pop img {
  max-width: 100%;
}

.pop .title {
  margin-bottom: 20px;
  margin-top: 10px;
  color: #333333;
}

.pop .description {
  font-size: 0.95em;
  line-height: 1.4em;
}

.pop-img {
  border: 3px solid #ccc;
  border-radius: 50%;
  overflow: hidden;
  max-width: 300px;
  margin: 0 auto;
}

.pop-img img {
  width: 300px;
  height: auto;
}

.pop-box {
  display: block;
  text-align: center;
  margin-bottom: 20px;
}

.pop-box .content {
  padding: 25px;
}


  body {
    overflow-x: hidden;
    font-family: 'PT Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
    -webkit-tap-highlight-color: #006600;
    color: #333;
  }

  a {
    color: #fff;
  }

  a:hover {
    color: #000;
  }

  h2 {
    font-weight: 700;
    font-family: 'Kaushan Script', 'Helvetica Neue', Helvetica, Arial, sans-serif;
  }



  .clear-padding {
    padding: 10px 10px ;
  }

  .box-inner>.item {
    min-height: 400px;
    background-size: cover;
    background-position: center center;
  }

  .box-inner:hover {
    background: #fff;
    color: rgba(125, 185, 50, 0.8);
  }

  .box-inner {
    display: block;
    position: relative;
    overflow: hidden;
    margin: auto auto 1rem;
  }

  .box-inner .caption {
    display: flex;
    height: 100%;
    width: 100%;

    position: absolute;
    top: 0;
    bottom: 0;
    z-index: 1;
  }

  .box-inner .caption .caption-content {
    color: #fff;
    margin: auto 2rem 2rem;
  }

  .box-inner .caption .caption-content h2 {
    font-family: 'Ubuntu', Helvetica, sans-serif;
    text-transform: uppercase;
    text-shadow: 2px 2px 3px #333;
  }

  .box-inner .caption .caption-content p {
    font-weight: 300;
    font-size: 1.7rem;
    line-height: 2.2rem;
  }

  @media (min-width: 760px) {
    .box-inner {
      max-width: none;

      margin: 0;
    }
    .box-inner .caption {
      -webkit-transition: -webkit-clip-path 0.25s ease-out, background-color 0.7s;
      -webkit-clip-path: inset(0px);
      clip-path: inset(0px);
    }
    .box-inner .caption .caption-content {
      transition: opacity 0.25s;
      margin-left: 3rem;
      margin-right: 3rem;
      margin-bottom: 3rem;
    }
    .box-inner {
      -webkit-transition: -webkit-clip-path 0.25s ease-out;
      -webkit-clip-path: inset(-1px);
      clip-path: inset(-1px);
    }
    .box-inner:hover {

    }
    .box-inner:hover .caption {
      background-color: rgba(0, 102, 0, 0.7);
      -webkit-clip-path: inset(2rem);
      clip-path: inset(2rem);
    }
  }

  .animated {
    animation-duration: 1s;
    animation-fill-mode: both;
  }

  .animated.infinite {
    animation-iteration-count: infinite;
  }

  @keyframes flipInY {
    from {
      transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
      animation-timing-function: ease-in;
      opacity: 0;
    }

    40% {
      transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
      animation-timing-function: ease-in;
    }

    60% {
      transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
      opacity: 1;
    }

    80% {
      transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
    }

    to {
      transform: perspective(400px);
    }
  }

  .flipInY {
    backface-visibility: visible !important;
    animation-name: flipInY;
  }

  .orange {
    color: #bb7200;
  }


   .title {
	       font-weight: 700;
    font-family: 'Kaushan Script', 'Helvetica Neue', Helvetica, Arial, sans-serif;
    text-align: center;
    margin-top: 3rem;
    margin-bottom: 3rem;
    font-size: 3.4rem;
	margin-bottom: 10px;
  }
  .parallax {
    height: 600px;
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	color: #000;
	   font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  }

  .parallax-caption {
    position: absolute;
    top: 50%;
    width: 100%;
    text-align: center;
    margin: 0 auto;
  }

  /*--------- Filter ---------*/
.filter {
  position: relative;
  height: 100%;
  color: #333;
}
.filter:before {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  display: block;
  z-index: 3;
  content: "";
  opacity: .5;
  background: #415d45;
}
.filter .filter-color:before {
  background: #333;
}

  .azzera {
    padding: 0;
    margin: 0;
  }

    .mar-tb {
    margin-top: 0;
    margin-bottom: 0;
  }

</style>

<div style="margin-bottom: 30px;" class="container-fluid">
    <div class="row">
      <div class="col-md-12 mar-tb azzera">
        <div class="parallax" style=" height:500px; background-image: url(http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/angie.jpg);">
          <h2 class="parallax-caption">CON FOREVER LIVING IGIENE E SALUTE PER TUTTA LA FAMIGLIA <br>
            <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=9005"><button type="button" class="btn btn-default font">Scopri di più</button></a></h2>
        </div>
      </div>
    </div>
  </div>


 <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <div class="pop pop-box">
          <div class="content">
            <div class="pop-img">
              <img alt="" src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/start.jpg" />
            </div>
            <div class="description">
              <h3 class="title">Forever F.I.T.</h3>

              <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=9012"><button type="button" class="btn btn-default font">Scopri il programma</button></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="pop pop-box">
          <div class="content">
            <div class="pop-img">
              <img alt="" src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/sport.jpg" />
            </div>
            <div class="description">
              <h3 class="title">Integratori</h3>

              <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=9009"><button type="button" class="btn btn-default font">Guarda i prodotti</button></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="pop pop-box">
          <div class="content">
            <div class="pop-img">
              <img alt="" src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/aloe.jpg" />
            </div>
            <div class="description">
              <h3 class="title">Aloe Vera Gel</h3>

              <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=9001"><button type="button" class="btn btn-default font">Scopri i 10 buoni motivi</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-4">
        <div class="pop pop-box">
          <div class="content">
            <div class="pop-img">
              <img alt="" src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/animali3.jpg" />
            </div>
            <div class="description">
              <h3 class="title">Amici Animali</h3>

              <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=9006"><button type="button" class="btn btn-default font">Scopri i prodotti</button></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="pop pop-box">
          <div class="content">
            <div class="pop-img">
              <img alt="" src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/oil.jpg" />
            </div>
            <div class="description">
              <h3 class="title">Mantenersi in forma</h3>

              <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=9014"><button type="button" class="btn btn-default font">Trova l'energia giusta</button></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="pop pop-box">
          <div class="content">
            <div class="pop-img">
              <img alt="" src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/beauty.jpg" />
            </div>
            <div class="description">
              <h3 class="title">Per la bellezza</h3>

              <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_contents&f4a=build_show_content&content_id=9004"><button type="button" class="btn btn-default font">La linea Sonya</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<div class="section block-popup">
    <div class="parallax filter filter-color">
        <div class="image" style="background-image:url('http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/parallax.jpg')">
        </div>
        <div class="container">
          <div class="row">
              <div class="col-md-12">
                <div class="row">
                <div class="col-md-4">
                    <div class="pop pop-box">
                        <div class="content">
                          <div class="pop-img">
                             <img alt="..." src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/circle_aloe.jpg"/>
                          </div>
                          <div class="description">
                              <h3 class="title">Lavora con Noi</h3>
                              <p class="description">Se il tuo lavoro o la tua carriera non portano al raggiungimento delle tue mete, Forever Living Products ti offre una grande opportunità per cambiare la tua vita.</strong></p>
                              <a href="http://www.idffy.it/mariadamico/index.php?f4o=load&f4m=tng_community_job_opportunity&f4a=build_job_oppportunity_main_page"><button type="button" class="btn btn-secondary font">Leggi ancora</button></a>
                          </div>
                         </div>
                      </div>
                </div>
                <div class="col-md-4">
                    <div class="pop pop-box">
                        <div class="content">
                          <div class="pop-img">
                             <img alt="..." src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/circle_products.jpg"/>
                          </div>
                          <div class="description">
                              <h3 class="title">Acquista</h3>

                              <p class="description">Bevande, integratori, cosmesi, oli essenziali e tanto altro ancora! Tutto questo è Forever Living Products. Scopri i nostri prodotti ed un modo per avere uno stile di vita più sano</p>
                              <a href="https://shop.foreverliving.it/shop.html?Tag_utente=390300119361" target="_blank"><button type="button" class="btn btn-secondary font">Consulta il catalogo</button></a>
                          </div>
                         </div>
                      </div>
                </div>
                <div class="col-md-4">
                    <div class="pop pop-box">
                        <div class="content">
                          <div class="pop-img">
                             <img alt="..." src="http://www.idffy.it/site_200/fstore/modules/contents/301/media_files/circle_news.jpg"/>
                          </div>
                          <div class="description">
                              <h3 class="title">Registrati</h3>

                              <p class="description">Entra a far parte del mondo Forever e potrai scegliere se acquistare per uso personale o diventare un Incaricato Indipendente e promuovere i prodotti.</p>
                              <a href="https://shop.foreverliving.it/registrazione-sponsorizzata-390300119361.html" target="_blank"><button type="button" class="btn btn-secondary font">Scopri ora</button></a>
                          </div>
                         </div>
                      </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
    </div>
</div></div></div>
   <div id="TNG_main_layout_template_table_left_cell" class="col-sm-12 col-md-3 col-md-pull-9 col-lg-2 col-lg-pull-8"></div>
   <div id="TNG_main_layout_template_table_right_cell" class="col-sm-12 col-md-3 col-lg-2"></div>
  </div>
  <div class="row">
   <div id="TNG_main_layout_template_table_center_cell" class="col-sm-12"></div>
  </div>
 </div>
</div>

<footer id="TNG_main_layout_template_footer_container">
<div class="tng_footer_responsive_PUBLIC_make_block_footer_menu_responsive_wrapper_container">
 <div class="tng_footer_responsive_PUBLIC_make_block_footer_menu_responsive_container row">
  <div class="col-md-2 hidden-xs hidden-sm"></div>
  <div class="col-xs-12 col-md-8 footer_menu_responsive">
  <ul class="footer_menu"><li><a href="index.php?" title="Home" target=""> Home</a></li><li><a href="index.php?f4o=load&f4m=tng_community_contattami&f4a=build_contact_me_form" title="Contattami" target=""> Contattami</a></li><li><a href="index.php?f4o=load&f4m=tng_community_miei_appuntamenti&f4a=build_show_miei_appuntamenti" title="Eventi" target=""> Eventi</a></li><li><a href="index.php?f4o=load&f4m=tng_community_blog&f4a=build_show_blog" title="Blog" target=""> Blog</a></li><li><a href="https://shop.foreverliving.it/registrazione-sponsorizzata-390300119361.html" title="Registrazione" target="_blank"> Registrazione</a></li><li><a href="index.php?f4o=load&f4m=tng_community_area_riservata&f4a=build_show_area_riservata" title="Area Riservata" target=""> Area Riservata</a></li>
  </ul>
  
  </div>
  <div class="col-md-2 hidden-xs hidden-sm"></div>
 </div>
 <div class="row">
  <div class="col-md-12 footer_copyright_text_container">&copy; 2018 ForeverForYou</div>
 </div>
</div></footer>

</div>
</body>
</html>